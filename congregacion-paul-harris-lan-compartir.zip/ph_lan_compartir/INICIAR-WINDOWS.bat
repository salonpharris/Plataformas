@echo off
title Congregacion Paul Harris LAN
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Node.js no esta instalado. Instala Node.js LTS desde https://nodejs.org
 pause
 exit /b
)
call npm install
call npm start
pause
