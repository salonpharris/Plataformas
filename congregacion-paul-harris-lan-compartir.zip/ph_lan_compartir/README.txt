
CONGREGACIÓN PAUL HARRIS LAN

1. Instala Node.js LTS desde https://nodejs.org
2. Descomprime este ZIP.
3. Ejecuta INICIAR-WINDOWS.bat.
4. En cada dispositivo (PC, tablet o celular conectado a la MISMA red Wi-Fi/cable)
   abre en el navegador: http://localhost:3000  (o la IP que muestra la consola)

5. Aparecerá una pantalla de bienvenida con dos botones:

   🎤 ORADOR  -> Solo visualiza el tema, orador y el tiempo restante.
                 Úsalo en el dispositivo que estará frente al orador
                 para ayudarle a no pasarse del tiempo. No permite editar nada.

   🎚️ SONIDO  -> Panel de control completo: agregar/editar temas, iniciar,
                 detener, enviar mensajes, etc. Se puede abrir en hasta
                 3 dispositivos SONIDO a la vez; todos ven y controlan
                 el mismo estado en tiempo real.

6. Desde el panel SONIDO puedes:
   - Presionar "🔗 Copiar enlace del ORADOR" para copiar el enlace y pegarlo
     en el navegador del dispositivo del orador.
   - Presionar "▣ Abrir vista ORADOR" para abrirlo en una ventana nueva
     (útil si el PC de SONIDO también maneja un segundo monitor/proyector).
   - Presionar "◷ Solo Reloj (en ORADOR)" para que la pantalla del ORADOR
     muestre solo un reloj grande (por ejemplo durante un cántico o receso).
     Esto SOLO afecta la pantalla del ORADOR, no el panel de SONIDO.

Atajos directos (por si quieres guardarlos como favoritos):
   http://IP:3000/#sonido   -> abre directo el panel de control
   http://IP:3000/#orador   -> abre directo la vista del orador

Todo funciona exclusivamente dentro de la red local: el PC/servidor y todos
los dispositivos (SONIDO y ORADOR) deben estar conectados a la misma red
Wi-Fi o red de cable. Si Windows Firewall pregunta, permite el acceso en
redes privadas.
