
const express = require('express');
const http = require('http');
const os = require('os');
const { Server } = require('socket.io');
const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = 3000;

let state = {
  events: [{ id: String(Date.now()), topic: 'Título de la Asignación', speaker: 'Nombre del Orador', time: 300, message: '' }],
  activeEventId: null,
  remaining: 300,
  isPaused: false,
  clockOnly: false,
  display: { topic: '', speaker: '', timer: '05:00', message: 'Bienvenidos', fullMessage: '', fullMessageVisible: false, warning: '', warningMode: false, overtime: false }
};
let interval = null;

function format(sec){ const a=Math.abs(sec); return String(Math.floor(a/60)).padStart(2,'0')+':'+String(a%60).padStart(2,'0'); }
function timerText(sec){ return sec < 0 ? '+' + format(sec) : format(sec); }
function warning(){
  const s = state.remaining;
  state.display.overtime = s < 0;
  if (s <= 30) { state.display.warning = 'DEBE FINALIZAR SU TEMA'; state.display.warningMode = true; }
  else if (s <= 60) { state.display.warning = 'SU TIEMPO ESTÁ FINALIZANDO'; state.display.warningMode = false; }
  else { state.display.warning = ''; state.display.warningMode = false; }
}
function emit(){ io.emit('state', state); }
function stopInterval(){ if(interval) clearInterval(interval); interval=null; }
function tick(){ state.remaining--; state.display.timer = timerText(state.remaining); warning(); emit(); }
function ips(){
  const nets = os.networkInterfaces(); const out = [];
  for (const n of Object.keys(nets)) for (const net of nets[n]) if(net.family === 'IPv4' && !net.internal) out.push(net.address);
  return out;
}

app.use(express.static('public'));
app.get('/api/network', (req,res)=>res.json({port:PORT, displayUrls: ips().map(ip => `http://${ip}:${PORT}/#orador`)}));

io.on('connection', socket => {
  socket.emit('state', state);

  socket.on('saveEvents', events => {
    if(!Array.isArray(events)) return;
    state.events = events.slice(0,10).map(e => ({
      id: String(e.id || Date.now()+Math.random()),
      topic: String(e.topic || ''),
      speaker: String(e.speaker || ''),
      time: Math.max(60, Number(e.time) || 300),
      message: String(e.message || '')
    }));
    emit();
  });

  socket.on('start', id => {
    const e = state.events.find(x => x.id === id);
    if(!e) return;
    stopInterval();
    state.activeEventId = id;
    state.remaining = e.time;
    state.isPaused = false;
    state.display.topic = e.topic;
    state.display.speaker = e.speaker;
    state.display.message = '';
    state.display.fullMessage = '';
    state.display.fullMessageVisible = false;
    state.display.timer = timerText(state.remaining);
    warning();
    interval = setInterval(tick, 1000);
    emit();
  });

  socket.on('stop', () => {
    stopInterval();
    state.isPaused = true;
    state.activeEventId = null;
    state.display.warning = '';
    state.display.warningMode = false;
    state.display.overtime = false;
    emit();
  });

  socket.on('continue', () => {
    if(!state.isPaused) return;
    state.isPaused = false;
    stopInterval();
    interval = setInterval(tick, 1000);
    emit();
  });

  socket.on('messageBelow', id => {
    const e = state.events.find(x => x.id === id);
    if(!e) return;
    state.display.message = e.message;
    state.display.fullMessage = '';
    state.display.fullMessageVisible = false;
    emit();
  });

  socket.on('messageFull', id => {
    const e = state.events.find(x => x.id === id);
    if(!e) return;
    state.display.message = '';
    state.display.fullMessage = e.message;
    state.display.fullMessageVisible = true;
    emit();
  });

  socket.on('hideMessage', () => {
    state.display.message = '';
    state.display.fullMessage = '';
    state.display.fullMessageVisible = false;
    emit();
  });

  socket.on('clockOnly', enabled => { state.clockOnly = !!enabled; emit(); });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('\nCongregacion Paul Harris LAN iniciado');
  console.log('Bienvenida (elegir modo): http://localhost:' + PORT);
  console.log('Panel SONIDO: http://localhost:' + PORT + '/#sonido');
  ips().forEach(ip => console.log('Vista ORADOR: http://' + ip + ':' + PORT + '/#orador'));
  console.log('Mantén esta ventana abierta.\n');
});
